#coding=utf-8
'''
Created on 2013年8月17日

@author: liaopengkai
'''

class MySQL:
    pass